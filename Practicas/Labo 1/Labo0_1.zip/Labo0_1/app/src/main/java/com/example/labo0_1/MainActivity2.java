package com.example.labo0_1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity2 extends AppCompatActivity {
    private LinearLayout layout1, layout2;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Primer Layout
        layout1 = new LinearLayout(this);
        layout1.setOrientation(LinearLayout.VERTICAL);
        layout1.setBackgroundColor(Color.BLACK);

        // Texto en el primer layout
        TextView texto1 = new TextView(this);
        texto1.setText("Este es el Primer Layout");

        // Botón para cambiar al segundo layout
        Button botonCambio1 = new Button(this);
        botonCambio1.setText("Ir al segundo layout");

        // Añadir campo EditText
        EditText lacaja = new EditText(this);
        lacaja.setText("Escriba su nombre: ");

        botonCambio1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(layout2);
                String user = lacaja.getText().toString();
            }
        });
        layout1.addView(texto1);
        layout1.addView(botonCambio1);
        layout1.addView(lacaja);

        // Segundo layout
        layout2 = new LinearLayout(this);
        layout2.setOrientation(LinearLayout.VERTICAL);
        layout2.setBackgroundColor(Color.WHITE);

        // Texto en el segundo layout
        TextView texto2 = new TextView(this);
        texto2.setText("Este es el Segundo Layout");
        TextView textoPersonalizado = new TextView(this);
        textoPersonalizado.setText("Bienvenido "+user);

        // Boton para regrasar al primer layout
        Button botonCambio2 = new Button(this);
        botonCambio2.setText("Volver al primer layout");

        botonCambio2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(layout1);
            }
        });

        layout2.addView(texto2);
        layout2.addView(botonCambio2);
        layout2.addView(textoPersonalizado);

        setContentView(layout1);

    }

}
